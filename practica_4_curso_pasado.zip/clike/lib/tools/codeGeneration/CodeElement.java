//*****************************************************************
// File:   CodeElement.java
// Author: Procesadores de Lenguajes-University of Zaragoza
// Date:   abril 2022
// Coms:   Clase abstracta que representa un elemento de código 
//*****************************************************************

package lib.tools.codeGeneration;

public abstract class CodeElement {

}
